```py
rotator = GeminiKeyRotator()

...
model=Gemini(id="gemini-2.5-flash-preview-05-20",api_key=rotator.get_current_key()),
GEMINI_KEYS=cccc-xxx,xxxx,xxxx,xxxx
```